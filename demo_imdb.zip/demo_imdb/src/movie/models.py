from django.db import models
from soul.models import SoulModel
import uuid
from django.conf import settings
import os
from manager import MovieManager, ReviewManager
from django.db.models.signals import post_save
from django.db.models import Avg


def sort_files_by_extension(self, filename):
    fname, extension = os.path.splitext(filename)
    self.original_name = filename
    self.modified_name = str(uuid.uuid4()) + str(extension)
    return settings.MEDIA_ROOT + "/" + self.modified_name


class Movie(SoulModel):
    movie_name = models.CharField(max_length=50, blank=False, null=False, db_index=True)
    year = models.PositiveSmallIntegerField(blank=False, null=False)
    duration = models.PositiveSmallIntegerField(blank=False, null=False)
    director = models.CharField(max_length=20, blank=True, null=True)
    description = models.TextField(blank=True, null=True)
    is_active = models.BooleanField(default=True)
    path = models.ImageField(null=True, upload_to=sort_files_by_extension,
                             max_length=500, verbose_name="Upload")
    original_name = models.CharField(null=True, max_length=200, editable=False)
    modified_name = models.CharField(null=True, max_length=200, unique=True, db_index=True, editable=False)
    average_rating = models.DecimalField(max_digits=2, decimal_places=1, default="0.0")

    objects = MovieManager()
    default_objects = models.Manager()

    class Meta:
        app_label = "movie"
        db_table = "movie_movie"

    def __unicode__(self):
        return self.movie_name

    def save(self, force_insert=False, force_update=False, using=None):
        #import pdb;pdb.set_trace()
        super(Movie, self).save(force_insert, force_update, using)

class Review(SoulModel):
    movie = models.ForeignKey(Movie, related_name="reviewmovies")
    comment = models.TextField(blank=False)
    rating = models.SmallIntegerField(default=0, blank=False)
    is_active = models.BooleanField(default=True)

    objects = ReviewManager()
    default_objects = models.Manager()

    class Meta:
        app_label = "movie"
        db_table = "movie_review"

    def __unicode__(self):
        return self.comment

    def save(self, force_insert=False, force_update=False, using=None):
        #import pdb;pdb.set_trace()
        super(Review, self).save(force_insert, force_update, using)

    def clean(self):
        from django.core.exceptions import ValidationError
        if self.rating > 5:
            raise ValidationError("Rating can be between 1 to 5!")


def update_avg_rating(sender, instance, created, **kwargs):
    """
    when review is created it will calculate avg rating and save it to movie field
    :param sender: Model Review
    :param instance: review object created
    :param created:
    :param kwargs:
    :return:
    """
    total_rating = Review.objects.filter(movie=instance.movie).aggregate(Avg('rating'))
    movie = Movie.objects.get(id=instance.movie.id)
    movie.average_rating = total_rating.get('rating__avg',0)
    movie.save()

post_save.connect(update_avg_rating, sender=Review)

