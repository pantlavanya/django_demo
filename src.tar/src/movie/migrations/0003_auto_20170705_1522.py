# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ('movie', '0002_auto_20170705_1519'),
    ]

    operations = [
        migrations.AlterModelOptions(
            name='movie',
            options={},
        ),
        migrations.AlterField(
            model_name='movie',
            name='duration',
            field=models.DurationField(),
        ),
        migrations.AlterModelTable(
            name='movie',
            table='movie_movie',
        ),
    ]
