from django.contrib import admin
from soul.admin import SoulAdminModel
from movie.models import Movie, Review
from django.utils.html import format_html


class MovieAdmin(SoulAdminModel):
    fieldsets = [('Information', {'fields': ['movie_name', 'year', 'duration', 'description', 'director']}),
                 ('Upload File', {'fields': ['path']}),
                 ('Is Active', {'fields': ['is_active']})]
    list_display = ('id', 'movie_name', 'duration', 'director', 'description','display_image_tag',
                    'average_rating', 'display_all_comments', 'created_at', 'created_by','is_active')
    list_filter = ['created_at', 'is_active','year']
    search_fields = ['movie_name', 'year']

    def display_image_tag(self, obj):
        return format_html("<img width='125', height='125' src='/media/%s' />"
                           % obj.modified_name)

    def display_all_comments(self, obj):
        return format_html("<a href='/admin/movie/review/?movie__id=%s'>Reviews</a>" % str(obj.id))

    display_all_comments.short_description = "All Comments"
    display_image_tag.short_description = 'Thumb'

    def get_queryset(self, request):
        qs = self.model.default_objects.get_queryset()
        return qs

class ReviewAdmin(SoulAdminModel):
    fieldsets = [('Information', {'fields': ['movie', 'comment']}),
                 ('Rating', {'fields': ['rating',]}),
                 ('Is Active', {'fields': ['is_active',]})]
    list_display = ('id', 'movie', 'comment','rating', 'created_at', 'created_by','is_active')
    list_filter = ['created_at', 'is_active']
    search_fields = ['movie', 'year']
    actions = ["export_csv"]

    def changelist_view(self, request, extra_context=None):
        return super(ReviewAdmin, self).changelist_view(request, extra_context=extra_context)

    def get_queryset(self, request):
        qs = self.model.default_objects.get_queryset()
        return qs

admin.site.register(Movie, MovieAdmin)
admin.site.register(Review, ReviewAdmin)