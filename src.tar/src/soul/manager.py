from django.db import models

class SoulManager(models.Manager):
    def get_queryset(self):
        return super(SoulManager, self).get_queryset().filter(is_active=True)