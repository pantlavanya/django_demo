from soul.manager import SoulManager
from django.core.cache import cache

class MovieManager(SoulManager):
    def get_queryset(self):
        return super(MovieManager, self).get_queryset()


class ReviewManager(SoulManager):
    def get_queryset(self):
        return super(ReviewManager, self).get_queryset()
