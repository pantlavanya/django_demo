from django.contrib import admin
from soul.utils import export_csv
from custom_middleware.current_user import get_current_user

# Register your models here.
class SoulAdminModel(admin.ModelAdmin):

    list_display = ('created_at','created_by')
    actions = [export_csv]

    def changelist_view(self, request, extra_context=None):
        return super(SoulAdminModel, self).changelist_view(request, extra_context=extra_context)

    def has_delete_permission(self, request, obj=None):
        return False

    def get_actions(self, request):
        actions = super(SoulAdminModel, self).get_actions(request)
        if 'delete_selected' in actions:
            del actions['delete_selected']
        return actions

