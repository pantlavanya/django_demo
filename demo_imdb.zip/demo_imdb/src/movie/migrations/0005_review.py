# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import migrations, models
import django.utils.timezone
from django.conf import settings


class Migration(migrations.Migration):

    dependencies = [
        migrations.swappable_dependency(settings.AUTH_USER_MODEL),
        ('movie', '0004_auto_20170705_1524'),
    ]

    operations = [
        migrations.CreateModel(
            name='Review',
            fields=[
                ('id', models.AutoField(verbose_name='ID', serialize=False, auto_created=True, primary_key=True)),
                ('created_at', models.DateTimeField(default=django.utils.timezone.now, editable=False, db_index=True)),
                ('updated_at', models.DateTimeField(default=django.utils.timezone.now, editable=False)),
                ('comment', models.TextField()),
                ('rating', models.SmallIntegerField(default=0)),
                ('is_active', models.BooleanField(default=True)),
                ('created_by', models.ForeignKey(related_name='review_created_by', default=None, blank=True, editable=False, to=settings.AUTH_USER_MODEL, null=True)),
                ('movie', models.ForeignKey(related_name='reviewmovies', to='movie.Movie')),
                ('updated_by', models.ForeignKey(related_name='review_updated_by', default=None, blank=True, editable=False, to=settings.AUTH_USER_MODEL, null=True)),
            ],
            options={
                'db_table': 'movie_review',
            },
        ),
    ]
